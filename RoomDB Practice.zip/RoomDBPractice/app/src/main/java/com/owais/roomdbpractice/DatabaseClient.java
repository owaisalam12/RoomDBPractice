package com.owais.roomdbpractice;

import android.content.Context;

import androidx.room.Room;

public class DatabaseClient {
    private Context context;
    private static DatabaseClient INSTANCE;

    private TaskAppDatabase taskAppDatabase;

    public DatabaseClient(Context context) {
        this.context = context;

        taskAppDatabase= Room.databaseBuilder(context,TaskAppDatabase.class,"MyToDos").build();


    }
    public static synchronized DatabaseClient getInstance(Context context){
        if(INSTANCE==null){
            INSTANCE=new DatabaseClient(context);
        }

        return INSTANCE;
    }

    public TaskAppDatabase taskAppDatabase(){
        return taskAppDatabase;
    }


}
