package com.owais.roomdbpractice;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {TaskDao.class},version = 1)
public abstract class TaskAppDatabase extends RoomDatabase {
    public abstract TaskDao getTaskDao();
}
